package com.max.clouddiscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClouddiscoveryserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
