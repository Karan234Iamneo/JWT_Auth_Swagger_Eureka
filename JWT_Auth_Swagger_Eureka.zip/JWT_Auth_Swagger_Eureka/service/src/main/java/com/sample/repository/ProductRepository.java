package com.sample.repository;

import com.sample.entity.Products;

import java.util.Optional;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Products, Integer> {
    // return all products
    List<Products> findAll();

    Optional<Products> findByProductId(int productId);
}